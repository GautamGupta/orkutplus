<div style="clear: both;"></div>

</div>

<div id="footer">
<center>All Content is Under Copyright Protection - &copy; Copyright <a href="http://orkutplus.net" target="_blank">Orkut Plus!</a> 2006-2009. All rights reserved.
<br /><a href="http://www.orkutplus.net/privacy-policy">Privacy Policy</a> | <a href="http://www.orkutplus.net/disclaimer">Disclaimer</a> | <a href="http://www.orkutplus.net/copyrights">Copyrights</a> | <a href="http://www.orkutplus.net/advertise">Advertise</a></center>
</div>

<?php wp_footer(); ?>