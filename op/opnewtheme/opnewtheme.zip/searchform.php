<div style="float:center;padding:45px 100px;">
<form action="search.php" id="cse-search-box">
<div>
<input type="hidden" name="cx" value="007418682267555033411:h1tpc4mtzre" />
<input type="hidden" name="cof" value="FORID:11" />
<input type="hidden" name="ie" value="UTF-8" />
<input type="text" name="q" size="31" />
<input type="submit" name="sa" value="Search" />
</div>
</form>
<script type="text/javascript" src="http://www.google.com/coop/cse/brand?form=cse-search-box&lang=en"></script>
</div>